﻿namespace library_app
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.Label0 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.TextBox2 = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.TextBox4 = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.TextBox6 = new System.Windows.Forms.TextBox();
            this.Label7 = new System.Windows.Forms.Label();
            this.TextBox8 = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.TextBox10 = new System.Windows.Forms.TextBox();
            this.Label11 = new System.Windows.Forms.Label();
            this.TextBox12 = new System.Windows.Forms.TextBox();
            this.Label13 = new System.Windows.Forms.Label();
            this.TextBox14 = new System.Windows.Forms.TextBox();
            this.Label15 = new System.Windows.Forms.Label();
            this.TextBox16 = new System.Windows.Forms.TextBox();
            this.Button17 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Label0
            // 
            this.Label0.AutoSize = true;
            this.Label0.Font = new System.Drawing.Font("Showcard Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label0.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.Label0.Location = new System.Drawing.Point(250, 9);
            this.Label0.Size = new System.Drawing.Size(298, 45);
            this.Label0.Text = "Welcome to Library";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.Label1.Location = new System.Drawing.Point(340, 80);
            this.Label1.Size = new System.Drawing.Size(93, 21);
            this.Label1.Text = "First Name:";
            // 
            // TextBox2
            // 
            this.TextBox2.Location = new System.Drawing.Point(250, 104);
            this.TextBox2.Size = new System.Drawing.Size(300, 23);
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.Label3.Location = new System.Drawing.Point(335, 130);
            this.Label3.Size = new System.Drawing.Size(105, 21);
            this.Label3.Text = "Second Name:";
            // 
            // TextBox4
            // 
            this.TextBox4.Location = new System.Drawing.Point(250, 154);
            this.TextBox4.Size = new System.Drawing.Size(300, 23);
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.Label5.Location = new System.Drawing.Point(360, 180);
            this.Label5.Size = new System.Drawing.Size(76, 21);
            this.Label5.Text = "Password:";
            // 
            // TextBox6
            // 
            this.TextBox6.Location = new System.Drawing.Point(250, 204);
            this.TextBox6.PasswordChar = '*';
            this.TextBox6.Size = new System.Drawing.Size(300, 23);
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.Label7.Location = new System.Drawing.Point(360, 230);
            this.Label7.Size = new System.Drawing.Size(68, 21);
            this.Label7.Text = "Address:";
            // 
            // TextBox8
            // 
            this.TextBox8.Location = new System.Drawing.Point(250, 254);
            this.TextBox8.Size = new System.Drawing.Size(300, 23);
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.Label9.Location = new System.Drawing.Point(370, 280);
            this.Label9.Size = new System.Drawing.Size(50, 21);
            this.Label9.Text = "Email:";
            // 
            // TextBox10
            // 
            this.TextBox10.Location = new System.Drawing.Point(250, 304);
            this.TextBox10.Size = new System.Drawing.Size(300, 23);
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.Label11.Location = new System.Drawing.Point(370, 330);
            this.Label11.Size = new System.Drawing.Size(90, 21);
            this.Label11.Text = "Birth Date:";
            // 
            // TextBox12
            // 
            this.TextBox12.Location = new System.Drawing.Point(250, 354);
            this.TextBox12.Size = new System.Drawing.Size(300, 23);
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.Label13.Location = new System.Drawing.Point(370, 380);
            this.Label13.Size = new System.Drawing.Size(55, 21);
            this.Label13.Text = "Phone:";
            // 
            // TextBox14
            // 
            this.TextBox14.Location = new System.Drawing.Point(250, 404);
            this.TextBox14.Size = new System.Drawing.Size(300, 23);
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Label15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(62)))), ((int)(((byte)(80)))));
            this.Label15.Location = new System.Drawing.Point(370, 430);
            this.Label15.Size = new System.Drawing.Size(92, 21);
            this.Label15.Text = "Student ID:";
            // 
            // TextBox16
            // 
            this.TextBox16.Location = new System.Drawing.Point(250, 454);
            this.TextBox16.Size = new System.Drawing.Size(300, 23);
            // 
            // Button17
            // 
            this.Button17.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Button17.ForeColor = System.Drawing.Color.White;
            this.Button17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(174)))), ((int)(((byte)(96)))));
            this.Button17.Location = new System.Drawing.Point(316, 500);
            this.Button17.Size = new System.Drawing.Size(170, 50);
            this.Button17.Text = "Sign Up";
            this.Button17.UseVisualStyleBackColor = false;
           // this.Button17.Click += new System.EventHandler(this.Button17_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(240)))), ((int)(((byte)(241)))));
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.Label0);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.TextBox2);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.TextBox4);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.TextBox6);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.TextBox8);
            this.Controls.Add(this.Label9);
            this.Controls.Add(this.TextBox10);
            this.Controls.Add(this.Label11);
            this.Controls.Add(this.TextBox12);
            this.Controls.Add(this.Label13);
            this.Controls.Add(this.TextBox14);
            this.Controls.Add(this.Label15);
            this.Controls.Add(this.TextBox16);
            this.Controls.Add(this.Button17);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Library Sign Up";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label Label0;
        private System.Windows.Forms.Label Label1;
        private System.Windows.Forms.TextBox TextBox2;
        private System.Windows.Forms.Label Label3;
        private System.Windows.Forms.TextBox TextBox4;
        private System.Windows.Forms.Label Label5;
        private System.Windows.Forms.TextBox TextBox6;
        private System.Windows.Forms.Label Label7;
        private System.Windows.Forms.TextBox TextBox8;
        private System.Windows.Forms.Label Label9;
        private System.Windows.Forms.TextBox TextBox10;
        private System.Windows.Forms.Label Label11;
        private System.Windows.Forms.TextBox TextBox12;
        private System.Windows.Forms.Label Label13;
        private System.Windows.Forms.TextBox TextBox14;
        private System.Windows.Forms.Label Label15;
        private System.Windows.Forms.TextBox TextBox16;
        private System.Windows.Forms.Button Button17;
    }
}

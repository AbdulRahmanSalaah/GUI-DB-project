namespace library_app
{
    partial class update_user
    {
         /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label0 = new System.Windows.Forms.Label();
            this.TextBox1 = new System.Windows.Forms.TextBox();
            this.TextBox2 = new System.Windows.Forms.TextBox();
            this.TextBox3 = new System.Windows.Forms.TextBox();
            this.TextBox4 = new System.Windows.Forms.TextBox();
            this.TextBox5 = new System.Windows.Forms.TextBox();
            this.TextBox6 = new System.Windows.Forms.TextBox();
            this.TextBox7 = new System.Windows.Forms.TextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.Label10 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.Label13 = new System.Windows.Forms.Label();
            this.Label16 = new System.Windows.Forms.Label();
            this.Label18 = new System.Windows.Forms.Label();
            this.Button20 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            //
            // Label0
            //
            this.Label0.AutoSize =  true;
            this.Label0.Text =  "Update Your Details";
            this.Label0.Font = new System.Drawing.Font("Segoe UI Black", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Label0.Location = new System.Drawing.Point(308,0);
            this.Label0.Size = new System.Drawing.Size(374,48);
            //
            // TextBox1
            //
            this.TextBox1.Location = new System.Drawing.Point(268,104);
            this.TextBox1.Size = new System.Drawing.Size(476,31);
            this.TextBox1.TabIndex = 1;
            //
            // TextBox2
            //
            this.TextBox2.Location = new System.Drawing.Point(268,180);
            this.TextBox2.Size = new System.Drawing.Size(476,31);
            this.TextBox2.TabIndex = 2;
            //
            // TextBox3
            //
            this.TextBox3.Location = new System.Drawing.Point(268,256);
            this.TextBox3.Size = new System.Drawing.Size(476,31);
            this.TextBox3.TabIndex = 3;
            //
            // TextBox4
            //
            this.TextBox4.Location = new System.Drawing.Point(268,332);
            this.TextBox4.Size = new System.Drawing.Size(480,31);
            this.TextBox4.TabIndex = 4;
            //
            // TextBox5
            //
            this.TextBox5.Location = new System.Drawing.Point(272,408);
            this.TextBox5.Size = new System.Drawing.Size(472,31);
            this.TextBox5.TabIndex = 5;
            //
            // TextBox6
            //
            this.TextBox6.Location = new System.Drawing.Point(268,480);
            this.TextBox6.Size = new System.Drawing.Size(476,31);
            this.TextBox6.TabIndex = 6;
            //
            // TextBox7
            //
            //this.TextBox7.CanUndo =  true;
            this.TextBox7.Modified =  true;
            this.TextBox7.Location = new System.Drawing.Point(268,552);
            this.TextBox7.Size = new System.Drawing.Size(476,31);
            this.TextBox7.TabIndex = 7;
            //
            // Label9
            //
            this.Label9.AutoSize =  true;
            this.Label9.Text =  "First Name";
            this.Label9.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            //this.Label9.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, Italic, System.Drawing.GraphicsUnit.Point);
            this.Label9.Location = new System.Drawing.Point(448,64);
            this.Label9.Size = new System.Drawing.Size(133,32);
            this.Label9.TabIndex = 9;
            //
            // Label10
            //
            this.Label10.AutoSize =  true;
            this.Label10.Text =  "Second Name";
            this.Label10.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            //this.Label10.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, Italic, System.Drawing.GraphicsUnit.Point);
            this.Label10.Location = new System.Drawing.Point(436,140);
            this.Label10.Size = new System.Drawing.Size(163,32);
            this.Label10.TabIndex = 10;
            //
            // Label11
            //
            this.Label11.AutoSize =  true;
            this.Label11.Text =  "Passowrd";
            this.Label11.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            //this.Label11.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, Italic, System.Drawing.GraphicsUnit.Point);
            this.Label11.Location = new System.Drawing.Point(460,216);
            this.Label11.Size = new System.Drawing.Size(116,32);
            this.Label11.TabIndex = 11;
            //
            // Label12
            //
            this.Label12.AutoSize =  true;
            this.Label12.Text =  "Address";
            this.Label12.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            //this.Label12.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, Italic, System.Drawing.GraphicsUnit.Point);
            this.Label12.Location = new System.Drawing.Point(476,296);
            this.Label12.Size = new System.Drawing.Size(99,32);
            this.Label12.TabIndex = 12;
            //
            // Label13
            //
            this.Label13.AutoSize =  true;
            this.Label13.Text =  "Email";
            this.Label13.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            //this.Label13.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, Italic, System.Drawing.GraphicsUnit.Point);
            this.Label13.Location = new System.Drawing.Point(488,368);
            this.Label13.Size = new System.Drawing.Size(75,32);
            this.Label13.TabIndex = 13;
            //
            // Label16
            //
            this.Label16.AutoSize =  true;
            this.Label16.Text =  "Birth Date";
            this.Label16.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            //this.Label16.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, Italic, System.Drawing.GraphicsUnit.Point);
            this.Label16.Location = new System.Drawing.Point(460,444);
            this.Label16.Size = new System.Drawing.Size(126,32);
            this.Label16.TabIndex = 16;
            //
            // Label18
            //
            this.Label18.AutoSize =  true;
            this.Label18.Text =  "Phone";
            this.Label18.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            //this.Label18.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, Italic, System.Drawing.GraphicsUnit.Point);
            this.Label18.Location = new System.Drawing.Point(480,516);
            this.Label18.Size = new System.Drawing.Size(81,32);
            this.Label18.TabIndex = 18;
            //
            // Button20
            //
            this.Button20.BackColor = System.Drawing.Color.MediumAquamarine;
            this.Button20.Text =  "Save";
            this.Button20.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Button20.Location = new System.Drawing.Point(452,624);
            this.Button20.Size = new System.Drawing.Size(128,56);
            this.Button20.TabIndex = 20;
         //
         // form
         //
            this.Size = new System.Drawing.Size(1036,756);
            this.Text =  "Form1";
            this.Controls.Add(this.Label0);
            this.Controls.Add(this.TextBox1);
            this.Controls.Add(this.TextBox2);
            this.Controls.Add(this.TextBox3);
            this.Controls.Add(this.TextBox4);
            this.Controls.Add(this.TextBox5);
            this.Controls.Add(this.TextBox6);
            this.Controls.Add(this.TextBox7);
            this.Controls.Add(this.Label9);
            this.Controls.Add(this.Label10);
            this.Controls.Add(this.Label11);
            this.Controls.Add(this.Label12);
            this.Controls.Add(this.Label13);
            this.Controls.Add(this.Label16);
            this.Controls.Add(this.Label18);
            this.Controls.Add(this.Button20);
            this.ResumeLayout(false);
        } 

        #endregion 

        private System.Windows.Forms.Label Label0;
        private System.Windows.Forms.TextBox TextBox1;
        private System.Windows.Forms.TextBox TextBox2;
        private System.Windows.Forms.TextBox TextBox3;
        private System.Windows.Forms.TextBox TextBox4;
        private System.Windows.Forms.TextBox TextBox5;
        private System.Windows.Forms.TextBox TextBox6;
        private System.Windows.Forms.TextBox TextBox7;
        private System.Windows.Forms.Label Label9;
        private System.Windows.Forms.Label Label10;
        private System.Windows.Forms.Label Label11;
        private System.Windows.Forms.Label Label12;
        private System.Windows.Forms.Label Label13;
        private System.Windows.Forms.Label Label16;
        private System.Windows.Forms.Label Label18;
        private System.Windows.Forms.Button Button20;
    }
}


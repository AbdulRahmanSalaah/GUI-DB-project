﻿namespace library_app
{
    partial class addBook
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RichTextBox0 = new System.Windows.Forms.RichTextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.RichTextBox3 = new System.Windows.Forms.RichTextBox();
            this.RichTextBox4 = new System.Windows.Forms.RichTextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.LinkLabel6 = new System.Windows.Forms.LinkLabel();
            this.Label7 = new System.Windows.Forms.Label();
            this.RichTextBox8 = new System.Windows.Forms.RichTextBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.RichTextBox10 = new System.Windows.Forms.RichTextBox();
            this.Label11 = new System.Windows.Forms.Label();
            this.RichTextBox12 = new System.Windows.Forms.RichTextBox();
            this.Label13 = new System.Windows.Forms.Label();
            this.RichTextBox14 = new System.Windows.Forms.RichTextBox();
            this.Label15 = new System.Windows.Forms.Label();
            this.RichTextBox16 = new System.Windows.Forms.RichTextBox();
            this.Label17 = new System.Windows.Forms.Label();
            this.RichTextBox18 = new System.Windows.Forms.RichTextBox();
            this.Button19 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // RichTextBox0
            // 
            this.RichTextBox0.Location = new System.Drawing.Point(84, 136);
            this.RichTextBox0.Name = "RichTextBox0";
            this.RichTextBox0.Size = new System.Drawing.Size(188, 44);
            this.RichTextBox0.TabIndex = 0;
            this.RichTextBox0.Text = "";
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(128, 104);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(87, 20);
            this.Label1.TabIndex = 1;
            this.Label1.Text = "Book Name";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(480, 136);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(37, 20);
            this.Label2.TabIndex = 2;
            this.Label2.Text = "Year";
            // 
            // RichTextBox3
            // 
            this.RichTextBox3.Location = new System.Drawing.Point(412, 168);
            this.RichTextBox3.Name = "RichTextBox3";
            this.RichTextBox3.Size = new System.Drawing.Size(188, 44);
            this.RichTextBox3.TabIndex = 3;
            this.RichTextBox3.Text = "";
            // 
            // RichTextBox4
            // 
            this.RichTextBox4.Location = new System.Drawing.Point(696, 136);
            this.RichTextBox4.Name = "RichTextBox4";
            this.RichTextBox4.Size = new System.Drawing.Size(188, 44);
            this.RichTextBox4.TabIndex = 4;
            this.RichTextBox4.Text = "";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(744, 108);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(98, 20);
            this.Label5.TabIndex = 5;
            this.Label5.Text = "No Of Copies";
            // 
            // LinkLabel6
            // 
            this.LinkLabel6.AutoSize = true;
            this.LinkLabel6.Location = new System.Drawing.Point(-280, 412);
            this.LinkLabel6.Name = "LinkLabel6";
            this.LinkLabel6.Size = new System.Drawing.Size(79, 20);
            this.LinkLabel6.TabIndex = 6;
            this.LinkLabel6.TabStop = true;
            this.LinkLabel6.Text = "LinkLabel6";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(276, 256);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(73, 20);
            this.Label7.TabIndex = 7;
            this.Label7.Text = "Author ID";
            // 
            // RichTextBox8
            // 
            this.RichTextBox8.Location = new System.Drawing.Point(228, 292);
            this.RichTextBox8.Name = "RichTextBox8";
            this.RichTextBox8.Size = new System.Drawing.Size(188, 44);
            this.RichTextBox8.TabIndex = 8;
            this.RichTextBox8.Text = "";
            // 
            // Label9
            // 
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(112, 392);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(88, 20);
            this.Label9.TabIndex = 9;
            this.Label9.Text = "Publisher ID";
            // 
            // RichTextBox10
            // 
            this.RichTextBox10.Location = new System.Drawing.Point(724, 420);
            this.RichTextBox10.Name = "RichTextBox10";
            this.RichTextBox10.Size = new System.Drawing.Size(188, 44);
            this.RichTextBox10.TabIndex = 10;
            this.RichTextBox10.Text = "";
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Location = new System.Drawing.Point(676, 256);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(98, 20);
            this.Label11.TabIndex = 11;
            this.Label11.Text = "Author Name";
            // 
            // RichTextBox12
            // 
            this.RichTextBox12.Location = new System.Drawing.Point(632, 292);
            this.RichTextBox12.Name = "RichTextBox12";
            this.RichTextBox12.Size = new System.Drawing.Size(188, 44);
            this.RichTextBox12.TabIndex = 12;
            this.RichTextBox12.Text = "";
            // 
            // Label13
            // 
            this.Label13.AutoSize = true;
            this.Label13.Location = new System.Drawing.Point(756, 388);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(113, 20);
            this.Label13.TabIndex = 13;
            this.Label13.Text = "Publisher Name";
            // 
            // RichTextBox14
            // 
            this.RichTextBox14.Location = new System.Drawing.Point(72, 424);
            this.RichTextBox14.Name = "RichTextBox14";
            this.RichTextBox14.Size = new System.Drawing.Size(188, 44);
            this.RichTextBox14.TabIndex = 14;
            this.RichTextBox14.Text = "";
            // 
            // Label15
            // 
            this.Label15.AutoSize = true;
            this.Label15.Location = new System.Drawing.Point(452, 404);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(114, 20);
            this.Label15.TabIndex = 15;
            this.Label15.Text = "Publisher Phone";
            // 
            // RichTextBox16
            // 
            this.RichTextBox16.Location = new System.Drawing.Point(408, 432);
            this.RichTextBox16.Name = "RichTextBox16";
            this.RichTextBox16.Size = new System.Drawing.Size(188, 44);
            this.RichTextBox16.TabIndex = 16;
            this.RichTextBox16.Text = "";
            // 
            // Label17
            // 
            this.Label17.AutoSize = true;
            this.Label17.Location = new System.Drawing.Point(480, 32);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(41, 20);
            this.Label17.TabIndex = 17;
            this.Label17.Text = "ISBN";
            // 
            // RichTextBox18
            // 
            this.RichTextBox18.Location = new System.Drawing.Point(408, 60);
            this.RichTextBox18.Name = "RichTextBox18";
            this.RichTextBox18.Size = new System.Drawing.Size(188, 44);
            this.RichTextBox18.TabIndex = 18;
            this.RichTextBox18.Text = "";
            // 
            // Button19
            // 
            this.Button19.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.Button19.Location = new System.Drawing.Point(428, 524);
            this.Button19.Name = "Button19";
            this.Button19.Size = new System.Drawing.Size(148, 72);
            this.Button19.TabIndex = 19;
            this.Button19.Text = "ADD BOOK";
            this.Button19.UseVisualStyleBackColor = false;
            // 
            // addBook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1052, 664);
            this.Controls.Add(this.Button19);
            this.Controls.Add(this.RichTextBox18);
            this.Controls.Add(this.Label17);
            this.Controls.Add(this.RichTextBox16);
            this.Controls.Add(this.Label15);
            this.Controls.Add(this.RichTextBox14);
            this.Controls.Add(this.Label13);
            this.Controls.Add(this.RichTextBox12);
            this.Controls.Add(this.Label11);
            this.Controls.Add(this.RichTextBox10);
            this.Controls.Add(this.Label9);
            this.Controls.Add(this.RichTextBox8);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.LinkLabel6);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.RichTextBox4);
            this.Controls.Add(this.RichTextBox3);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.RichTextBox0);
            this.Name = "addBook";
            this.Text = "Add Book";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox RichTextBox0;
        private System.Windows.Forms.Label Label1;
        private System.Windows.Forms.Label Label2;
        private System.Windows.Forms.RichTextBox RichTextBox3;
        private System.Windows.Forms.RichTextBox RichTextBox4;
        private System.Windows.Forms.Label Label5;
        private System.Windows.Forms.LinkLabel LinkLabel6;
        private System.Windows.Forms.Label Label7;
        private System.Windows.Forms.RichTextBox RichTextBox8;
        private System.Windows.Forms.Label Label9;
        private System.Windows.Forms.RichTextBox RichTextBox10;
        private System.Windows.Forms.Label Label11;
        private System.Windows.Forms.RichTextBox RichTextBox12;
        private System.Windows.Forms.Label Label13;
        private System.Windows.Forms.RichTextBox RichTextBox14;
        private System.Windows.Forms.Label Label15;
        private System.Windows.Forms.RichTextBox RichTextBox16;
        private System.Windows.Forms.Label Label17;
        private System.Windows.Forms.RichTextBox RichTextBox18;
        private System.Windows.Forms.Button Button19;
    }
}
